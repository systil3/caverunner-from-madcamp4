using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float jumpForce = 200f;
    public float moveSpeed;
    public float dashSpeed;
    public float dashDuration; // 대시 지속 시간
    public float dashCooldown; // 대시 쿨다운
    public Ghost ghost;

    private Rigidbody2D rb;
    private Vector2 moveDirection;
    private Vector2 horizontaldirection;
    private bool isDashing;
    private bool isJumping;
    private bool isFacingRight = true;
    private float dashTime;
    private float nextDashTime = 0f;

    private Animator animator;
    //private Transform CameraTransform;

    void Start(){
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        //CameraTransform = transform.Find("Camera");
    }

    void Update(){
        ProcessInputs();
        Move();

        if (isDashing){
            if (Time.time >= dashTime){
                StopDash();
            }
        }
        else{
            if (Input.GetKeyDown(KeyCode.LeftShift) && Time.time >= nextDashTime){
                ghost.makeghost = true;
                StartDash();
            } else {
                ghost.makeghost = false;
            }

        }
    }

    void ProcessInputs()
    {
        float moveX = Input.GetAxisRaw("Horizontal");
        float moveY = Input.GetAxisRaw("Vertical");
        moveDirection = new Vector2(moveX, moveY).normalized;
        if(moveY >0){
            moveDirection+=new Vector2(0,0.3f);
        }

        if ((moveX > 0 && !isFacingRight) || (moveX < 0 && isFacingRight))
        {
            FlipSprite();
        }
        horizontaldirection = new Vector2(moveX, 0).normalized;
    }

    void FlipSprite()
    {
        // 캐릭터의 방향을 반전
        isFacingRight = !isFacingRight;

        // 캐릭터의 스케일을 반전
        Vector3 scale = transform.localScale;
        scale.x *= -1;
        //CameraTransform.localScale *= -1;
        transform.localScale = scale;
    }

    void Move()
    {   
        if(horizontaldirection != Vector2.zero) {
            transform.Translate(horizontaldirection*moveSpeed*Time.deltaTime);
            animator.SetBool("isWalking", true);
        } else {
            animator.SetBool("isWalking", false);
        }
        
        if(Input.GetKeyDown(KeyCode.Space) && animator.GetBool("isJumping") == false){
            Jump();
        }
    }

    void Jump() {
        animator.SetBool("isJumping", true);
        rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }

    void StartDash()
    {
        isDashing = true;
        dashTime = Time.time + dashDuration;
        nextDashTime = Time.time + dashCooldown;
        Debug.Log($"{moveDirection}");
        rb.AddForce(moveDirection * dashSpeed, ForceMode2D.Impulse);
    }

    void StopDash()
    {
        isDashing = false;
        rb.velocity = moveDirection * moveSpeed; // 대시 후 속도 초기화
    }

    private void OnCollisionEnter2D(Collision2D collision) {
        if(collision.transform.tag == "wall") {
            animator.SetBool("isJumping", false);
            print("wall");
        }
    }
}